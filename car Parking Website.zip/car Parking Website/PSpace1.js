
let Parray= document.querySelectorAll('div')[0].children;
let act= document.querySelector('.btn');
  
 let fetchData= fetch('PSpace1.json');
 console.log(fetchData);
    fetchData.then((responseObj)=>{
        console.log(responseObj);
        let JsonObj= responseObj.json();
        // console.log(JObj);
        return JsonObj;
    }).then((JObj)=>{
        console.log(JObj);
        if(JObj.S1 === 0)
            {
                Parray[0].className= 'Free';
                Parray[0].innerHTML= '1<br><span class="smallText">Free</span>';
            }
            else{
                Parray[0].className= 'Occupied';
                Parray[0].innerHTML= '1<br><span class="smallText">Occupied</span>';
            }
            if(JObj.S2 === 0)
            {
                Parray[1].className= 'Free';
                Parray[1].innerHTML= '2<br><span class="smallText">Free</span>';
            }
            else{
                Parray[1].className= 'Occupied';
                Parray[1].innerHTML= '2<br><span class="smallText">Occupied</span>';
            }
            if(JObj.S3 === 0)
            {
                Parray[2].className= 'Free';
                Parray[2].innerHTML= '3<br><span class="smallText">Free</span>';
            }
            else{
                Parray[2].className= 'Occupied';
                Parray[2].innerHTML= '3<br><span class="smallText">Occupied</span>';
            }
    });

    const star= ()=>{
        window.location.href= 'PSpace2.html';
    }
    act.addEventListener('click',star);