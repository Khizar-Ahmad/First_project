 let btn= document.body.querySelector('.btnF');
 let Topic= document.body.querySelector('#exampleInputEmail1');
 let detailT= document.body.querySelector('#dddd');
 let imageUrl= document.body.querySelector('#ddd');
 let i=0;
 const openForm=()=>{
    // window.location.href='Form_practice.html';
    
    i++;
    if(i%2 !== 0){
        let createbtn= document.createElement('button');
    createbtn.textContent= "Delete Post";
    let postV=document.createElement('div');
    postV.setAttribute('class','row featurette d-flex justify-content-center align-items-center mt-5');
    let catForm= document.body.querySelector('.cat1');
    let dataPost='<div class="col-md-7 order-md-2"><h2 class="featurette-heading ">'+Topic.value+'</h2><p class="lead">'+detailT.value+'</p></div><div class="col-md-5 order-md-1"><img src="'+imageUrl.value+'" class="img-fluid " width="500" height="350" alt="" style="margin-bottom: 4px"></div>';
    postV.innerHTML= dataPost;
    postV.firstElementChild.firstElementChild.nextElementSibling.append(createbtn);
    catForm.after(postV);
    let HrTag= document.createElement('hr');
    HrTag.setAttribute('class','featurette-divider');
    postV.after(HrTag);
    createbtn.addEventListener('click',()=>{
        let parentId= document.body.querySelector('.claa');
        parentId.removeChild(postV);
    })
}
else{
    let createbtn= document.createElement('button');
    createbtn.textContent= "Delete Post";
    let postV=document.createElement('div');
    postV.setAttribute('class','row featurette d-flex justify-content-center align-items-center');
    let catForm= document.body.querySelector('.cat1');
    let dataPost='<div class="col-md-7"><h2 class="featurette-heading ">'+Topic.value+'</h2><p class="lead">'+detailT.value+'</p></div><div class="col-md-5"><img src="'+imageUrl.value+'" class="img-fluid " width="500" height="350" alt=""></div>';
    postV.innerHTML= dataPost;
    postV.firstElementChild.firstElementChild.nextElementSibling.append(createbtn);
    catForm.after(postV);
    let HrTag= document.createElement('hr');
    HrTag.setAttribute('class','featurette-divider');
    postV.after(HrTag);
    createbtn.addEventListener('click',()=>{
        let parentId= document.body.querySelector('.claa');
        parentId.removeChild(postV);
    })
   
}

    Topic.value='';
    detailT.value='';
    imageUrl.value= '';

    
   
  
   
 }

 btn.addEventListener('click',openForm)